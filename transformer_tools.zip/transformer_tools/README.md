Transformer Tools
======================

Some utilities for working with transformers and T5; somewhat ad-hoc
in many places, please use with caution. 

For known issues, see `KNOWN_ISSUES.md`. 

Basic setup
----------------------------

We suggest using [**conda**](https://docs.conda.io/en/latest/miniconda.html) for creating a python environment, and doing the following:
```bash
conda create -n transformer_tools python=3.6.7
conda activate transformer_tools ## after setting up above
pip install -r requirements.txt
python -m spacy download en  ## (optional for some demos)
```
Below are some of the current use cases. 

Running T5 for QA
----------------------------
One main utility here is the T5 model, to run this and see all of its
options, do the following:
```bash
./run.sh {T5Generator,T5Classifier} --help 
```

The following trains a T5(-large) classifier model on a version of the babi
data:
```bash
./run.sh  T5Classifier \
          --dtype mcqa \
          --output_dir _runs/example \
          --data_dir etc/data/mix_babi \
          --num_train_epochs "12" \
          --model_name_or_path  t5-large \
          --tokenizer_name_or_path t5-large \
          --learning_rate "0.0005" \
          --train_batch_size "16" \
          --seed "42" \
          --max_seq_len "250" \
          --max_answer, "10" \
          --early_stopping \
          --dev_eval \
          --patience "4" \
          --num_beams "2" \
          --print_output \
          --no_repeat_ngram_size "0" \
          --T5_type T5ClassificationMultiQA \
          --data_builder  multi_qa
```
and will place the output into `_runs/example` (to see the final
output, check `_runs/example/dev_eval.tsv`, also to check that
everything looks correct). The final scores will be stored in
`metrics.json`, which gives me the following after running the
experiment above:
```json
{
  "best_dev_score": 0.9195979899497487,
  "dev_eval": 0.9195979899497487
}
```


In the `data_dir` it will expect 2 (optionally 3) files:
`{train,test,dev}.jsonl`, where each line has the following format
(for QA type tasks):
```json
{
    "id": "4297_dev",
    "question" :
        {
            "stem": "Bill got the milk there. Following that he
            discarded the milk there. Mary is not in ..."
        },
    "answerKey": -1,
    "output": "no",
    "prefix": "answer:"
}
```


**Using a trained model directly** From the terminal, you can use the
code from above for testing by setting `--target_model` to the
target model directory and using the `--no_train` directive. Here's
the full call:
```bash
./run.sh  T5Classifier \
          --dtype mcqa \
          --output_dir _runs/example_test \
          --data_dir etc/data/mix_babi \
          --model_name_or_path  t5-large \
          --tokenizer_name_or_path t5-large \
          --max_seq_len "250" \
          --max_answer, "10" \
          --dev_eval \
          --no_training \         # <-------- important!
          --target_model /mode/dir # <-------- important!
          --num_beams "2" \
          --print_output \
          --no_repeat_ngram_size "0" \
          --T5_type T5ClassificationMultiQA \
          --data_builder  multi_qa \
```

Here is how it can be done through the terminal (see also `notebooks/load_t5_babi-model.ipynb`):
```python
>>> from transformer_tools import LoadT5Classifier,get_config
>>> gen_config = get_config("transformer_tools.T5Classifier")
>>> gen_config.target_model = "path/to/output/directory/above"
>>> gen_config.max_answer = 200
>>> model = LoadT5Generator(gen_config)
>>> model.query("target query here..")
```


Setting up with wandb
---------------------------

Here's an example of running a T5 with wandb on the backend:
```python
python  -m  transformer_tools T5Classifier \
        --output_dir /output \
         --data_dir  /inputs \
         --dev_eval \
         --wdir /output \
         --T5_type T5ClassificationMultiQA \
         --data_builder  multi_qa \
         --wandb_project "t5_model_runs" \ #<---- name of project
         --wandb_name "t5_small_backup_test" \ #<----- name of wandbexp. 
         --wandb_entity "eco-semantics" \ #<--- project id
         --save_wandb_model \ #<--- backup the resulting model on wandb
         --wandb_api_key "xxxxxxxxxxxxxxxxxxxx" #<--- wandb api key (if needed)
```
**NOTE**: `wandb_api_key` is not safe to broadcast like this; if not
running in a cloud environment, it is best to set this as an
environment variable.
