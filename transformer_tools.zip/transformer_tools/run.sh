python -m transformer_tools "$@"
